# mp_tictactoe

This is an Online multiplayer Tictacktoe game where two player can play simultaneously. Whoever gets 6 points of score first wins the game. one player have to create a room and others have to join the room my inputing rooms ID number given by the player1(Who has created the room). The Project in coded in flutter language and javacsript and nodejs is used for backend/server. and mongoDB is used for Database to store the player's details.

![Tictactoe](https://user-images.githubusercontent.com/81036521/177798657-de5dfd5f-d04d-437f-bc6e-1293e90b4b16.png)


You can download the apk from the [release](https://github.com/AadrianLeo/Tictactoe-Multiplayer-Game/releases)

You can even play it online on web : [web link](https://tictactoe-online-game.netlify.app/)

### `#For flutter packages run: pub get  && to run flutter project run : flutter run  or in vscode click on run from the banner and click on run without debugging or start degugging.`

### `# for packages of server go in server directory and run npm i or npm install.`
